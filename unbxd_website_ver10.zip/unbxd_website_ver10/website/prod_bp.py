# from flask import Blueprint
# from flask import Blueprint,render_template,request,jsonify
# from flask import Flask,request,jsonify,redirect

# prod_bp=Blueprint('prod_bp', __name__)

# @prod_bp.route('/products',methods=['GET','POST'])
# def home():
#     data=request.form
#     print(data)
#     return render_template("products.html",boolean=True)